﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  class Array
{
    int[] weights;
    int size;
    Array(int tam)
    {
        this.weights = new int[tam];
        this.size = 0;
    }
    void push(int data)
    {
        weights[size] = data;
        this.size++;
    }
    int get(int i)
    {
        return weights[i];
    }
    int pop()
    {
        if (size >= 0)
            size--;
        return weights[size];
    }
}