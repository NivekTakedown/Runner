﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomGenerator : MonoBehaviour
{
    public Transform object_;
    public GameObject[] obj;
    float maxTime=0.7f;
    float minTime=1.3f;
    private Vector2 screenBounds;
    // Start is called before the first frame update
    void Start()
    {
        NotificationCenter.DefaultCenter().AddObserver(this, "CharRun");
        screenBounds = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, Camera.main.transform.position.z));

    }
    void CharRun() {
        generate();
    }

    // Update is called once per frame
    void Update()
    {
       /* if (transform.position.x < screenBounds.x)
        {
            Destroy(this.obj);
        }*/
    }
    void generate()
    {
        Instantiate(obj[Random.Range(0, obj.Length)], object_.position, object_.rotation);
        Invoke("generate", Random.Range(minTime, maxTime));
    }
}
