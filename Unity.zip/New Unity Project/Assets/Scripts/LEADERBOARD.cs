﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public class LEADERBOARD : MonoBehaviour
{
    public PlayerControlater pc;
    public COUNTER c;
    //private string

    // Start is called before the first frame update
    void Start()
    {
        //CreateBoard();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    /* void CreateBoard()
    {

        if (pc.wallCol)
        {
            string path = Application.dataPath + "/Log.txt";
            if (!File.Exists(path))
            {
                File.WriteAllText(path, c.FinalScore + "\n");
            }
            else
            {
                File.AppendAllText(path, c.FinalScore + "\n");
            }

            Time.timeScale = 0f;
        }



    }
    void Save() {
        BinaryFormatter bf = new BinaryFormatter;
        FileStream file = new FileStream("C:\Users\KanoPort\Desktop\New Unity Project");
    }*/

}
/*[Serializable]
class SaveData {
    public int A;
    public SaveData(A) {
        this.A = A;
    }
}*/