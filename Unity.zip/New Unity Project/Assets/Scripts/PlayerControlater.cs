﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControlater : MonoBehaviour
{

    public float jumpForce = 100f;
    private bool onFloor = false;
    public bool wallCol = false;
    public Transform floorComprovate;
    private float radioComprovate = 0.05f;
    public LayerMask floorMask;
    public Transform wallComprovate;

    public Rigidbody2D rb;

    private bool doubleJump = false;

    private Animator animator;
    public bool running = false;
    public float speed = 1f;

    void Awake() {
        animator = GetComponent<Animator>();
    }

    // Start is called before the first frame update
    void Start() {
        // rb = GetComponent<Rigidbody2D>();
        // animator = GetComponent<Animator>();
    }
    void FixedUpdate()
    {
        if (running)
        {
            rb.AddForce(new Vector2(speed, rb.velocity.y));
        }
        animator.SetFloat("VelX", rb.velocity.x);
        onFloor = Physics2D.OverlapCircle(floorComprovate.position, radioComprovate, floorMask);
        animator.SetBool("isGrounded", onFloor);
        wallCol = Physics2D.OverlapCircle(wallComprovate.position, radioComprovate, floorMask);
        if (onFloor)
        {
            doubleJump = false;
        }
    }
   /* void Stop()
    {
        
    }*/

    // Update is called once per frame
    void Update() {
        if(Input.GetMouseButtonDown(0)) {
            if (running) {
                // Saltar si puede hacerlo
                if (onFloor || !doubleJump) {
                    rb.AddForce(new Vector2(rb.velocity.x, jumpForce));                  
                    if (!doubleJump && !onFloor) {
                        doubleJump = true;
                    }
                }
            } 
            else {
                running = true;
                NotificationCenter.DefaultCenter().PostNotification(this, "CharRun");
            }
        }


    }

    
}