﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class COUNTER : MonoBehaviour
{
    public PlayerControlater pc;
    public int Score;
    public int FinalScore;
    public Text SC;
    private int i=0;
    
    void Start()
    {
    }

    void Update()
    {
        if (pc.running && !pc.wallCol) {
            if (i == 10)
            {
                AddScore();
                i = 0;
            }

            i++;
        }


    }

    void AddScore() {
        Score++;
        SC.text = Score.ToString();
        if (pc.wallCol) {
            FinalScore = Score;
        }
    }

    
}
